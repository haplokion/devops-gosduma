ЛОГИН - ПАРОЛЬ
admin - admin
moderator - moderator
user - user