SECRET_KEY="iw7L9]:r(u~d&*XR/q}P:;#LQN5)5}akyw!YKVug"
MYSQL_USER='std_2409_exam'
MYSQL_PASSWORD="12345678"
MYSQL_HOST='std-mysql.ist.mospolytech.ru'
MYSQL_DATABASE='std_2409_exam'